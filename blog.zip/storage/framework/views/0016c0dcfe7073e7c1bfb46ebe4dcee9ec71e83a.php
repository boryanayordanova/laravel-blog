<?php $__env->startSection("content"); ?>

	 <div class="col-sm-8 blog-main">
		<h1><?php echo e($post->title); ?></h1>

		<?php echo e($post->body); ?>



	<?php if($post->tags): ?>
	<ul>
		<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li>
			<a href="/posts2/tags/<?php echo e($tag->name); ?>">
			<?php echo e($tag->name); ?>

			</a>
		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	<?php endif; ?>


		<hr>
		

		<div class="comments">
			<ul class="list-group">
				<?php $__currentLoopData = $post->commentsfunction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class="list-grouo-item">
						<strong>
							<?php echo e($c->created_at->diffForHumans()); ?>: &nbsp;
				        </strong>

				             <?php echo e($c->body); ?>

					</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>



		
		<hr>

		<div class="card">
			<div class="card-block">

				<form method="POST" action="/posts2/<?php echo e($post->id); ?>/comments">


					<?php echo e(csrf_field()); ?>




					<div class="form-group">
						<textarea name="body" placeholder="Your comment here..." class="form-control"></textarea>
					</div>

					<div class="form-group">
						<button type="submit" class="btn btn-primary">Add Comment</button>
					</div>

				</form>

				<?php echo $__env->make("layouts.errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
		</div>

	 </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/posts2.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>