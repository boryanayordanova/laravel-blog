<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Email</title>
</head>
<body>

	<h1>Welcome to laracast <?php echo e($user->name); ?></h1>
</body>
</html>