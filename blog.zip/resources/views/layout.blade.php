<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>	My application</title>
</head>
<body>

	@yield('content');
	
</body>
</html>