@extends("layouts.master")

@section("content")
	<h1>A place to show the post</h1>
@endsection